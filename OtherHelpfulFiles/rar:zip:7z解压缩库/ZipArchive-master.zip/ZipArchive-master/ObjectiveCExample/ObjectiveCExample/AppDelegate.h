//
//  AppDelegate.h
//  ObjectiveCExample
//
//  Created by Sean Soper on 10/23/15.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

