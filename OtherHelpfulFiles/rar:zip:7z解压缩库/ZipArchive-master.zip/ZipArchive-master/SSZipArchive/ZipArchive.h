//
//  ZipArchive.h
//  ZipArchive
//
//  Created by Serhii Mumriak on 12/1/15.
//  Copyright © 2015 smumryak. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ZipArchive.
FOUNDATION_EXPORT double ZipArchiveVersionNumber;

//! Project version string for ZipArchive.
FOUNDATION_EXPORT const unsigned char ZipArchiveVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZipArchive/SSZipArchive.h>

#import "SSZipArchive.h"
