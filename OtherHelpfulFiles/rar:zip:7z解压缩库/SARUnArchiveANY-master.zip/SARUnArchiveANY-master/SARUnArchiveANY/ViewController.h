//
//  ViewController.h
//  SARUnArchiveANY
//
//  Created by Saravanan V on 26/04/13.
//  Copyright (c) 2013 SARAVANAN. All rights reserved.
//


#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (void)handleFileFromURL:(NSString *)filePath;

@end
